import pygame
import toolbox
import math
from explosion import Explosion
from crate import *


class WaterBalloon (pygame.sprite.Sprite):
    def __init__(self, screen, x, y, angle, from_enemy = False):
        pygame.sprite.Sprite.__init__(self, self.containers)

        self.screen = screen
        self.x = x
        self.y = y
        self.angle = angle
        self.image = pygame.image.load("../assets/BalloonSmall.png")
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.angle_rads = math.radians(self.angle)
        self.speed = 5
        self.x_move = math.cos(self.angle_rads)*self.speed
        self.y_move = -math.sin(self.angle_rads) * self.speed
        self.damage = 7
        self.sfx_splash = pygame.mixer.Sound("../assets/sfx/splash.wav")
        self.sfx_splash.set_volume(0.5)
        self.kind = 'normal'
        self.from_enemy = from_enemy
        self.timer = -1


        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)

    def explode(self):
        explosion_images = []
        explosion_images.append(pygame.image.load("../assets/SplashSmall1.png"))
        explosion_images.append(pygame.image.load("../assets/SplashSmall2.png"))
        explosion_images.append(pygame.image.load("../assets/SplashSmall3.png"))
        Explosion(self.screen, self.x, self.y, explosion_images, 7, 1, False)
        self.kill()
        self.sfx_splash.play()

    def update(self):
        self.x += self.x_move
        self.y += self.y_move
        self.rect.center = (self.x, self.y)
        self.screen.blit(self.image, self.rect)

        if self.x < -self.image.get_width():
            self.kill()

        elif self.x > self.screen.get_width() + self.image.get_width():
            self.kill()

        elif self.y < -self.image.get_height():
            self.kill()

        elif self.y > self.screen.get_height() + self.image.get_height():
            self.kill()
            
        if self.timer > 0:
            self.timer -= 1
        if self.timer == 0:
            self.explode()

class Droplet(WaterBalloon):
    def __init__(self, screen, x, y, angle):
        WaterBalloon.__init__(self, screen, x, y, angle)
        self.image = pygame.image.load("../assets/DropSmall.png")
        self.rect = self.image.get_rect()
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect,  self.angle)
        self.damage = 3

class ExplosiveWaterBalloon(WaterBalloon):
    def __init__(self, screen, x, y, angle):
        WaterBalloon.__init__(self, screen, x, y, angle)
        self.image = pygame.image.load("../assets/Balloon.png")
        self.rect = self.image.get_rect()
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)
        self.sfx_heavy_splash = pygame.mixer.Sound("../assets/sfx/splash-heavy.wav")
        self.sfx_heavy_splash.set_volume(0.5)
        self.kind = 'explosive'

    def explode(self):
        explosion_images = []
        explosion_images.append(pygame.image.load("../assets/SplashLarge1.png"))
        explosion_images.append(pygame.image.load("../assets/SplashLarge2.png"))
        explosion_images.append(pygame.image.load("../assets/SplashLarge3.png"))
        Explosion(self.screen, self.x, self.y, explosion_images, 7, 1, False)
        self.kill()
        self.sfx_heavy_splash.play()

class SpeedBalloon(WaterBalloon):
    def __init__(self, screen, x, y, angle):
        WaterBalloon.__init__(self, screen, x, y, angle)
        self.image = pygame.image.load("../assets/BalloonSmallFlash.png")
        self.rect = self.image.get_rect()
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)
        self.kind = 'speed'

class ExplosiveAmmo(WaterBalloon):
    def __init__(self, screen, x, y, angle, player):
        WaterBalloon.__init__(self, screen, x, y, angle, True)
        self.image = pygame.image.load("../assets/powerupExplosiveCrate.png")
        self.rect = self.image.get_rect()
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)
        self.kind = 'crate'
        self.player = player
        self.timer = 150

    def explode(self):
        ExplosiveCrate(self.screen, self.x, self.y, self.player)
        self.kill()
