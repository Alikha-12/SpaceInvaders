import pygame

class Button:
    def __init__(self, screen, x, y, width, height, text):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text
        self.rect = pygame.Rect(x, y, width, height)
        self.screen = screen
        self.text_font = pygame.font.SysFont("default", 30)

    def update(self):
        self.font = self.text_font.render(self.text, True, (255, 255, 255))
        text_x = self.x + self.width / 2 - self.font.get_width() / 2
        text_y = self.y + self.height / 2 - self.font.get_height() / 2
        pygame.draw.rect(self.screen, (0, 0, 0), self.rect, border_radius = 10)
        self.screen.blit(self.font, (text_x, text_y))
