import pygame
import math
import toolbox
from projectile import *
import random

class Companion(pygame.sprite.Sprite):
    def __init__(self, screen, x, y, player):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.screen = screen
        self.x = x
        self.y = y
        self.player = player
        self.angle = 0
        self.image = pygame.image.load("../assets/Enemy_03.png")
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.obstacle_anger_max = 50
        self.obstacle_anger = 0
        self.damage = 3
        self.shoot_timer_max = 50
        self.shoot_timer = self.shoot_timer_max
        self.health = 14
        self.speed_max = 4
        self.speed = self.speed_max
        self.speed_timer = self.speed_max
        self.sfx_die = pygame.mixer.Sound("../assets/sfx/explosion-small.wav")
        self.sfx_die.set_volume(0.5)
        self.target_angle = 0
    
    def move(self):
        self.rect.center = (self.x, self.y)
        angle = toolbox.angleBetweenPoints(self.x, self.y, self.player.x, self.player.y)
        angle_rads = math.radians(angle)
        self.x_move = math.cos(angle_rads) * self.speed
        self.y_move = -math.sin(angle_rads) * self.speed

    def angry(self, crates):
        test_rect = self.rect
        new_x = self.x + self.x_move
        new_y = self.y + self.y_move
        test_rect.center = (new_x, self.y)
        for crate in crates:
            if test_rect.colliderect(crate.rect):
                new_x = self.x
                self.getAngry(crate)
        test_rect.center = (self.x, new_y)
        for crate in crates:
            if test_rect.colliderect(crate.rect):
                new_y = self.y
                self.getAngry(crate)
        self.x = new_x
        self.y = new_y
        self.rect.center = (self.x, self.y)
        
    def getAngry(self, crate):
        self.obstacle_anger += 1
        if self.obstacle_anger >= self.obstacle_anger_max:
            crate.getHit(self.damage)
            self.obstacle_anger = 0
            
    def getHit(self, damage, angle):
        self.health -= damage
        knockback_distance =  10
        x_knockback = knockback_distance * math.cos(angle)
        y_knockback = knockback_distance * -math.sin(angle)
        self.x += x_knockback
        self.y += y_knockback
        self.hurt_timer = 5

        if self.health <= 0:
            explosion_images = []
            explosion_images.append(pygame.image.load("../assets/LargeExplosion1.png"))
            explosion_images.append(pygame.image.load("../assets/LargeExplosion2.png"))
            explosion_images.append(pygame.image.load("../assets/LargeExplosion3.png"))
            Explosion(self.screen, self.x, self.y, explosion_images, 7, 1, False)
            self.health = 9999
            self.sfx_die.play()
            self.kill()
            self.player.getScore(50)
            
    def takeDamage(self, projectiles, explosions):
        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect) and projectile.from_enemy:
                self.getHit(projectile.damage, projectile.angle)
                projectile.explode()
                if projectile.kind == 'speed':
                    self.speed += 5
                    self.speed_timer = self.speed_timer_max
        self.speed_timer -= 1
        if self.speed_timer <= 0:
            self.speed = self.speed_max
            
        for explosion in explosions:
            if explosion.damage:
                if self.rect.colliderect(explosion.rect):
                    angle = math.atan2(-(self.y - explosion.y), self.x - explosion.x)
                    self.getHit(explosion.damage, angle)
                    
    def updateAngle(self):
        if self.angle == self.target_angle:
            return 0
        
        if self.angle > self.target_angle:
            clockwise = self.angle - self.target_angle
            counter_clockwise = (360 - self.angle + self.target_angle) % 360
        else:
            counter_clockwise = self.target_angle - self.angle
            clockwise = (360 - self.target_angle + self.angle) % 360
        if clockwise < counter_clockwise:
            self.angle += (counter_clockwise - clockwise) / 16
        elif counter_clockwise < clockwise:
            self.angle -= (clockwise - counter_clockwise) / 16
        

    def update(self, crates, enemies, explosions, projectiles):
        self.takeDamage(projectiles, explosions)
        if math.dist([self.x, self.y], [self.player.x, self.player.y]) > 256:
            self.move()
            self.angry(crates)
        closest_enemy = None
        min_distance = float('inf')
        for enemy in enemies:
            if math.dist([self.x, self.y], [enemy.x, enemy.y]) < min_distance:
                min_distance = math.dist([self.x, self.y], [enemy.x, enemy.y])
                closest_enemy = enemy
        if closest_enemy is not None and min_distance < 64:
            self.target_angle = math.degrees(math.atan2(closest_enemy.y - self.y, self.x - closest_enemy.x))
        else:
            self.target_angle = toolbox.angleBetweenPoints(self.x, self.y, self.player.x, self.player.y) + 180
        while self.angle < 0:
            self.angle += 360
        while self.angle >= 360:
            self.angle -= 360
        while self.target_angle < 0:
            self.target_angle += 360
        while self.target_angle >= 360:
            self.target_angle -= 360
        image, image_rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)
        self.screen.blit(image, image_rect)
        self.shoot_timer -= 1
        if min_distance <= 350:
            if self.shoot_timer <= 0:
                self.shoot_timer = self.shoot_timer_max
                WaterBalloon(self.screen, self.x, self.y, self.angle, False)
        self.updateAngle()
       
