import pygame
from projectile import *
from enemy import *

class PayloadProjectile(WaterBalloon):
    def __init__(self, screen, x, y, angle, player, difficulty, from_enemy = True):
        WaterBalloon.__init__(self, screen, x, y, angle, from_enemy)
        self.image = pygame.image.load("../assets/payload.png")
        self.rect = self.image.get_rect()
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect,  self.angle)
        self.player = player
        self.timer = 50
        self.difficulty = difficulty
        
    def explode(self):
        new_enemy = Enemy(self.screen, self.x, self.y, self.player, self.difficulty)
        if self.difficulty == 'hard':
            new_enemy.changeSpeed(3)
        self.kill()
