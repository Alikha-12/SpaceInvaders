import pygame
import toolbox
from button import *

class HUD():
    def __init__(self, screen, player):
        self.screen = screen
        self.player = player
        self.state = 'mainmenu'
        self.hud_font = pygame.font.SysFont("default", 30)
        self.crate_icon = pygame.image.load("../assets/Crate.png")
        self.explosive_crate_icon = pygame.image.load("../assets/ExplosiveBarrel.png")
        self.balloon_icon = pygame.image.load("../assets/BalloonSmall2.png")
        self.split_icon = pygame.image.load("../assets/iconSplit.png")
        self.stream_icon = pygame.image.load("../assets/iconStream.png")
        self.burst_icon = pygame.image.load("../assets/iconBurst.png")
        self.normal_icon = pygame.image.load("../assets/BalloonSmall.png")
        self.crate_ammo_tile = AmmoTile(self.screen, self.crate_icon, self.hud_font)
        self.explosive_crate_ammo_tile = AmmoTile(self.screen, self.explosive_crate_icon, self.hud_font)
        self.balloon_ammo_tile = AmmoTile(self.screen, self.balloon_icon, self.hud_font)
        self.title_image = pygame.image.load("../assets/AOTR_title.png")
        self.start_text = pygame.image.load("../assets/BtnPlay.png")
        self.hud_font_big = pygame.font.SysFont("default", 80)
        self.reset_button = pygame.image.load("../assets/BtnReset.png")
        self.easy_button = pygame.image.load("../assets/BtnEasy.png")
        self.medium_button = pygame.image.load("../assets/BtnMedium.png")
        self.hard_button = pygame.image.load("../assets/BtnHard.png")
        self.difficulty = 'easy'
        self.button1 = Button(screen, 10, 10, 180, 50, "Heal $1")
        self.button2 = Button(screen, 10 + 180 + 10, 10, 180, 50, "Max Health $1")
        self.button3 = Button(screen, 10 + 180 + 10 + 180 + 10, 10, 180, 50, "Coin Booster $2")
        self.button4 = Button(screen, 10 + 180 + 10 + 180 + 10 + 180 + 10, 10, 180, 50, "Damage Increase $1")

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_h]:
            self.state = 'upgrades'
            
        if self.state == 'ingame':
            self.score_text = self.hud_font.render("Score " + str(self.player.score), True,(255, 255, 255))
            self.screen.blit(self.score_text,(10, 10))
            self.kill_text = self.hud_font.render("Kill " + str (self.player.kill_counter), True, (255, 255, 255))
            self.screen.blit(self.kill_text, (100, 10))
            if self.player.shot_type == 'normal':
                self.balloon_ammo_tile.icon = self.normal_icon
            if self.player.shot_type == 'split':
                self.balloon_ammo_tile.icon = self.split_icon
            if self.player.shot_type == 'stream':
                self.balloon_ammo_tile.icon = self.stream_icon
            if self.player.shot_type == 'burst':
                self.balloon_ammo_tile.icon = self.burst_icon
            self.crate_ammo_tile.update(50, self.screen.get_height(), self.player.crate_ammo)
            self.explosive_crate_ammo_tile.update(250, self.screen.get_height(), self.player.explosive_crate_ammo)
            self.balloon_ammo_tile.update(350, self.screen.get_height(), self.player.special_ammo)
        elif self.state == 'mainmenu':
            self.screen.blit(self.title_image, toolbox.centeringCoord(self.title_image, self.screen))
            text_x, text_y = toolbox.centeringCoord(self.start_text, self.screen)
            self.screen.blit(self.start_text, (text_x, text_y + 50))
            button_x, button_y = toolbox.centeringCoord(self.easy_button, self.screen)
            if self.difficulty == 'easy':
                self.screen.blit(self.easy_button, (button_x, button_y + 180))
            if self.difficulty == 'medium':
                self.screen.blit(self.medium_button, (button_x, button_y + 180))
            if self.difficulty == 'hard':
                self.screen.blit(self.hard_button, (button_x, button_y + 180))
            
        elif self.state == 'gameover':
            self.gameover_text = self.hud_font_big.render("Game Over!", True, (255, 255, 255))
            self.final_score_text = self.hud_font.render("Final Score " + str(self.player.score), True, (255, 255,255))
            self.screen.blit(self.gameover_text, (self.screen.get_width()/2 - self.gameover_text.get_width()/2, self.screen.get_height()/2 - self.gameover_text.get_height()/2 - 60))
            final_score_x, final_score_y = toolbox.centeringCoord(self.final_score_text, self.screen)
            final_score_y += 60 - 60
            self.screen.blit(self.final_score_text, (final_score_x, final_score_y))
            reset_button_x, reset_button_y = toolbox.centeringCoord(self.reset_button, self.screen)
            button_rect = self.screen.blit(self.reset_button, (reset_button_x, reset_button_y + 100))
            events = pygame.event.get()
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_position = pygame.mouse.get_pos()
                    if button_rect.collidepoint(mouse_position):
                        self.state = 'mainmenu'
                        
        elif self.state == 'upgrades':
            self.button1.update()
            self.button2.update()
            self.button3.update()
            self.button4.update()
            keys = pygame.key.get_pressed()
            if keys[pygame.K_g]:
                self.state = 'ingame'
            self.coin_text = self.hud_font.render("Coin " + str(self.player.coin_counter), True, (255, 255, 255))
            health_string = "Health " + str(self.player.health) + "/" + str(self.player.health_max)
            self.health_text = self.hud_font.render(health_string, True, (255, 255, 255))
            self.screen.blit(self.coin_text, (10, self.screen.get_height() - self.coin_text.get_height() - 10))
            self.screen.blit(self.health_text, (10 + self.coin_text.get_width() + 30, self.screen.get_height() - self.coin_text.get_height() - 10))
            

class AmmoTile():
    def __init__(self, screen, icon, font):
        self.screen = screen
        self.icon = icon
        self.font = font
        self.bg_image = pygame.image.load("../assets/hudTile.png")

    def update(self, x, y, ammo):
        tile_rect = self.bg_image.get_rect()
        tile_rect.bottomleft = (x, y)
        icon_rect = self.icon.get_rect()
        icon_rect.center = tile_rect.center
        ammo_text = self.font.render(str(ammo), True, (255, 255, 255))
    

        #drawing into the screen
        self.screen.blit(self.bg_image, tile_rect) #background
        self.screen.blit(self.icon, icon_rect) #icon
        self.screen.blit(ammo_text, tile_rect.topleft) #ammo text
