import pygame
import toolbox
import random


class Powerup(pygame.sprite.Sprite):
    def __init__(self, screen, x, y):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.screen = screen
        self.x = x
        self.y = y
        self.pick_power = random.randint(0,7)
        if self.pick_power == 0:
            self.image = pygame.image.load("../assets/powerupCrate.png")
            self.background_image = pygame.image.load("../assets/powerupBackgroundBlue.png")
            self.power_type = 'crateammo'
        elif self.pick_power == 1:
            self.image = pygame.image.load("../assets/powerupExplosiveBarrel.png")
            self.background_image = pygame.image.load("../assets/powerupBackgroundBlue.png")
            self.power_type = 'explosiveammo'
        elif self.pick_power == 2:
            self.image = pygame.image.load("../assets/powerupSplit.png")
            self.background_image = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = 'split'
        elif self.pick_power == 3:
            self.image = pygame.image.load("../assets/powerupDrop.png")
            self.background_image = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = 'stream'
        elif self.pick_power == 4:
            self.image = pygame.image.load("../assets/SplashSmall1.png")
            self.background_image = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = 'burst'
        elif self.pick_power == 5:
            self.image = pygame.image.load("../assets/BalloonSmallMagic.png")
            self.background_image = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = 'magic'
        elif self.pick_power == 6:
            self.image = pygame.image.load("../assets/BalloonSmallFlash.png")
            self.background_image = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = 'flash'
        elif self.pick_power == 7:
            self.image = pygame.image.load("../assets/companion_powerup.png")
            self.background_image = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = 'companion'
        self.sfx_pick = pygame.mixer.Sound("../assets/sfx/powerup.wav")
        self.sfx_pick.set_volume(0.5)
            
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.background_angle = 0
        self.spin_speed = 2
        self.timer_max = 500
        self.timer = self.timer_max

    def update(self, player):
        self.background_angle += self.spin_speed
        bg_image_to_draw, bg_rect = toolbox.getRotatedImage(self.background_image, self.rect, self.background_angle)

        if self.timer % 10 > 5 or self.timer > 120:
            self.screen.blit(bg_image_to_draw, bg_rect)
            self.screen.blit(self.image, self.rect)

        self.timer -= 1
        if self.timer <= 0 :
            self.kill()

        if self.rect.colliderect(player.rect):
            player.powerUp(self.power_type)
            self.kill()
            self.sfx_pick.play()
            
        
