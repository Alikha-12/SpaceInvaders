import pygame
import toolbox
import math
from projectile import *
from explosion import Explosion
from powerup import *
from coin import *
from particle import *


class Enemy(pygame.sprite.Sprite):
    def __init__(self, screen, x, y, player, difficulty):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.screen = screen
        self.x = x
        self.y = y
        self.player = player
        self.image = pygame.image.load("../assets/Enemy_02.png")
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.angle = 0
        self.speed_max = 0.9
        self.speed = self.speed_max
        self.health = 15
        self.x_move = 0
        self.y_move = 0
        self.image_hurt = pygame.image.load("../assets/Enemy_02_damaged.png")
        self.hurt_timer = 0
        self.damage = 1
        self.obstacle_anger = 0
        self.obstacle_anger_max = 50
        self.sfx_die = pygame.mixer.Sound("../assets/sfx/explosion-small.wav")
        self.sfx_die.set_volume(0.5)
        self.speed_timer_max = 100
        self.speed_timer = self.speed_timer_max
        self.difficulty = difficulty
        if difficulty == 'easy':
            self.health -= 5
        elif difficulty == 'medium':
            self.health += 0
        elif difficulty == 'hard':
            self.health += 10

    def breakApart(self):
        w = self.image.get_width()
        h = self.image.get_height()
        for i in range(10):
            crop_x = random.randint(0, w-10)
            crop_y = random.randint(0, h - 10)
            crop_w = random.randint(8, int(w/2))
            crop_h = random.randint(8, int(h/2))
            vx = random.randint(-10, 10)
            vy = random.randint(-10, 10)
            x = self.x
            y = self.y
            ax = 0
            ay = 0
            fx = 0.5
            fy = 0.5
            if crop_x + crop_w > w:
                crop_w = w - crop_x
            if crop_y + crop_h > h:
                crop_h = h - crop_y
            part = self.image.subsurface((crop_x, crop_y, crop_w, crop_h))
            Particle(part, x, y, vx, vy, ax, ay, fx, fy, random.randint(0,360))
            

    def changeSpeed(self, amount):
        self.speed += amount
        self.speed_max += amount
        
    def getAngry(self, crate):
        self.obstacle_anger += 1
        if self.obstacle_anger >= self.obstacle_anger_max:
            crate.getHit(self.damage)
            self.obstacle_anger = 0

    def getHit(self, damage, angle):
        self.health -= damage
        knockback_distance =  10
        if self.difficulty == 'easy':
            knockback_distance += 20
        x_knockback = knockback_distance * math.cos(angle)
        y_knockback = knockback_distance * -math.sin(angle)
        self.x += x_knockback
        self.y += y_knockback
        self.hurt_timer = 5
        
        if self.health <= 0:
            explosion_images = []
            explosion_images.append(pygame.image.load("../assets/LargeExplosion1.png"))
            explosion_images.append(pygame.image.load("../assets/LargeExplosion2.png"))
            explosion_images.append(pygame.image.load("../assets/LargeExplosion3.png"))
            Explosion(self.screen, self.x, self.y, explosion_images, 7, 1, False)
            self.health = 9999
            if random.randint(0, 100) < 50:
                Powerup(self.screen, self.x, self.y)
            self.sfx_die.play()
            self.kill()
            self.player.kill_counter += 1
            for i in range(self.player.coin_boost):
                Coin(self.screen, self.x + random.randint(-50, 50), self.y + random.randint(-50, 50))
            self.breakApart()
            self.player.getScore(50)

    def update(self, projectiles, crates, explosions):
        self.move()
        self.angry(crates)
        self.drawImage()
        self.takeDamage(projectiles, explosions)
                    
    def move(self):
        self.rect.center = (self.x, self.y)
        self.angle = toolbox.angleBetweenPoints(self.x, self.y, self.player.x, self.player.y)
        angle_rads = math.radians(self.angle)
        self.x_move = math.cos(angle_rads) * self.speed
        self.y_move = -math.sin(angle_rads) * self.speed

    def angry(self, crates):
        test_rect = self.rect
        new_x = self.x + self.x_move
        new_y = self.y + self.y_move
        test_rect.center = (new_x, self.y)
        for crate in crates:
            if test_rect.colliderect(crate.rect):
                new_x = self.x
                self.getAngry(crate)
        test_rect.center = (self.x, new_y)
        for crate in crates:
            if test_rect.colliderect(crate.rect):
                new_y = self.y
                self.getAngry(crate)
                
        self.x = new_x
        self.y = new_y
        self.rect.center = (self.x, self.y)

    def drawImage(self):
        if  self.hurt_timer > 0:
            self.hurt_timer -= 1

        if self.hurt_timer <= 0:
            image_to_rotate = self.image

        else:
            image_to_rotate = self.image_hurt
            
        image_to_draw, image_rect = toolbox.getRotatedImage(image_to_rotate, self.rect, self.angle)
        self.screen.blit(image_to_draw, image_rect)

    def takeDamage(self, projectiles, explosions):
        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect) and not projectile.from_enemy:
                self.getHit(projectile.damage, projectile.angle)
                projectile.explode()
                if projectile.kind == 'speed':
                    self.speed += 5
                    self.speed_timer = self.speed_timer_max
        self.speed_timer -= 1
        if self.speed_timer <= 0:
            self.speed = self.speed_max
            
        for explosion in explosions:
            if explosion.damage:
                if self.rect.colliderect(explosion.rect):
                    angle = math.atan2(-(self.y - explosion.y), self.x - explosion.x)
                    self.getHit(explosion.damage, angle)
                    
            

class ProjectileEnemy(Enemy):
    def __init__(self, screen, x, y, player, difficulty):
        Enemy.__init__(self, screen, x, y, player, difficulty)
        self.image = pygame.image.load("../assets/Enemy_05.png")
        self.image_hurt = pygame.image.load("../assets/Enemy_05_Hurt.png")
        self.shoot_cooldown_timer_max = 250
        self.shoot_cooldown_timer = self.shoot_cooldown_timer_max
        if difficulty == 'hard':
            self.shoot_cooldown_timer_max -= 50

    def update(self, projectiles, crates, explosions):
        x_diff = self.player.x - self.x
        y_diff = self.player.y - self.y
        distance = math.sqrt(x_diff * x_diff + y_diff * y_diff)
        if distance >96:
            self.move()
            self.angry(crates)
        self.drawImage()
        self.takeDamage(projectiles, explosions)
        self.shoot_cooldown_timer -= 1
        if self.shoot_cooldown_timer <= 0:
            self.shoot_cooldown_timer = self.shoot_cooldown_timer_max
            WaterBalloon(self.screen, self.x, self.y, self.angle, True)

class ExplosiveBarrel(Enemy):
    def __init__(self,screen, x, y, player, difficulty):
        Enemy.__init__(self, screen, x, y, player, difficulty)
        self.image = pygame.image.load("../assets/Enemy_01.png")
        self.image_hurt = pygame.image.load("../assets/Enemy_02.png")
        self.shoot_cooldown_timer_max = 200
        self.shoot_cooldown_timer = self.shoot_cooldown_timer_max

    def update(self, projectiles, crates, explosions):
        self.move()
        self.angry(crates)
        self.drawImage()
        self.takeDamage(projectiles, explosions)
        self.shoot_cooldown_timer -= 1
        if self.shoot_cooldown_timer <= 0:
            self.shoot_cooldown_timer = self.shoot_cooldown_timer_max
            ExplosiveAmmo(self.screen, self.x, self.y, self.angle + 5, self.player)
