import pygame
from enemy import *
from projectile import *
from adv_projectile import *

class ExplosiveEnemy(Enemy):
    def __init__(self, screen, x, y, player, difficulty):
        Enemy.__init__(self, screen, x, y, player, difficulty)
        self.image = pygame.image.load("../assets/Enemy_04.png")
        self.image_hurt = pygame.image.load("../assets/Enemy_03.png")
        self.shoot_cooldown_timer_max = 150
        self.shoot_cooldown_timer = self.shoot_cooldown_timer_max
        self.difficulty = difficulty

    def update(self, projectiles, crates, explosions):
        x_diff = self.player.x - self.x
        y_diff = self.player.y - self.y
        distance = math.sqrt(x_diff * x_diff + y_diff * y_diff)
        if distance >96:
            self.move()
            self.angry(crates)
        self.drawImage()
        self.takeDamage(projectiles, explosions)
        self.shoot_cooldown_timer -= 1
        if self.shoot_cooldown_timer <= 0:
            self.shoot_cooldown_timer = self.shoot_cooldown_timer_max
            PayloadProjectile(self.screen, self.x, self.y, self.angle, self.player, self.difficulty, True)


