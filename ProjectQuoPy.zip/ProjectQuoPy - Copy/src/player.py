import pygame
import toolbox
from projectile import *
from crate import *
from companion import *

class Player(pygame.sprite.Sprite):
    def __init__(self, screen, x, y):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.screen = screen
        self.x = x
        self.y = y
        self.image = pygame.image.load("../assets/Player_02_damaged.png")
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.speed_max = 5
        self.speed = self.speed_max
        self.angle = 0
        self.shoot_timer_max = 10
        self.shoot_timer = self.shoot_timer_max
        self.speed_timer_max = 200
        self.speed_timer = self.speed_timer_max
        self.health = 20
        self.hurt_timer = 0
        self.image_hurt = pygame.image.load("../assets/Player_02_damaged.png")
        self.health_max = self.health
        self.health_bar_width = self.image.get_width()
        self.health_bar_height = 8
        self.health_bar_green = pygame.Rect(0, 0, self.health_bar_width, self.health_bar_height)
        self.health_bar_red = pygame.Rect(0, 0, self.health_bar_width, self.health_bar_height)
        self.crate_ammo = 10
        self.crate_cooldown = 0
        self.crate_cooldown_max = 10
        self.explosive_crate_ammo = 70
        self.shot_type = 'normal'
        self.special_ammo = 0
        self.score = 0
        self.sfx_shot = pygame.mixer.Sound("../assets/sfx/shot.wav")
        self.sfx_shot.set_volume(0.5)
        self.coin_counter = 0
        self.counter_font = pygame.font.SysFont("default", 30)
        self.coin_boost = 1
        self.damage_boost = 0
        self.kill_counter = 0

    def getScore(self, score):
        if self.health > 0:
            self.score += score

    def getHit(self, damage):
        if self.hurt_timer <= 0:
            self.hurt_timer = 25
            self.health -= damage

    def placeCrate(self):
        if self.health > 0 and self.crate_ammo > 0 and self.crate_cooldown <= 0:
            Crate(self.screen, self.x, self.y, self)
            self.crate_ammo -= 1
            self.crate_cooldown = self.crate_cooldown_max

    def placeExplosiveCrate(self):
        if self.health > 0 and self.explosive_crate_ammo > 0 and self.crate_cooldown <= 0:
            ExplosiveCrate(self.screen, self.x, self.y, self)
            self.explosive_crate_ammo -= 1
            self.crate_cooldown = self.crate_cooldown_max


    def update(self, Enemies, explosions, projectiles, coins):
        self.score_text = self.counter_font.render("Coin " + str(self.coin_counter), True,(255, 255, 255))
        self.screen.blit(self.score_text,(150, 10))
        self.health_bar_red.x = self.rect.x
        self.health_bar_red.bottom = self.rect.y -5
        pygame.draw.rect(self.screen, (255, 0, 0), self.health_bar_red)
        self.health_bar_green.topleft = self.health_bar_red.topleft
        pygame.draw.rect(self.screen, (0, 255, 0), self.health_bar_green)
        health_percentage = self.health / self.health_max
        self.health_bar_green.width = self.health_bar_width * health_percentage
        
        if self.crate_cooldown > 0:
            self.crate_cooldown -= 1

        if self.hurt_timer > 0:
            self.hurt_timer -= 1
            
        if self.shoot_timer > 0:
            self.shoot_timer -= 1
            
        for enemy in Enemies:
            if self.rect.colliderect(enemy.rect):
                self.getHit(enemy.damage)

        for explosion in explosions:
            if self.rect.colliderect(explosion.rect):
                if explosion.damage > 0:
                    self.getHit(explosion.damage)
                    
        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect) and projectile.from_enemy:
                self.getHit(projectile.damage)
                projectile.explode()

        if self.shot_type == 'flash':
            self.speed_timer -= 1
            if self.speed_timer <= 0:
                self.speed = self.speed_max
        for coin in coins:
            if self.rect.colliderect(coin.rect):
                self.coin_counter += 1
                coin.kill()
            
                
        mouse_x, mouse_y = pygame.mouse.get_pos()
        self.angle = toolbox.angleBetweenPoints(self.x, self.y, mouse_x, mouse_y)
        if self.hurt_timer > 0:
            image_to_rotate = self.image_hurt
        else:
            image_to_rotate = self.image
        image_to_draw, image_rect = toolbox.getRotatedImage(image_to_rotate, self.rect, self.angle)

        if self.health >= 0:
            self.screen.blit(image_to_draw, image_rect)

    def move(self, x_movement, y_movement, crates):
        if self.health >= 0:
            test_rect = pygame.Rect.copy(self.rect)
            test_rect.x += self.speed * x_movement
            test_rect.y += self.speed * y_movement
            collision = False
            for crate in crates:
                if not crate.just_placed: 
                    if test_rect.colliderect(crate.rect):
                        collision = True
            if not collision:
                self.x += self.speed * x_movement
                self.y += self.speed * y_movement
                self.rect.center = (self.x, self.y)
            if self.rect.left < 0:
                self.rect.left = 0
            if self.rect.right > self.screen.get_width():
                self.rect.right = self.screen.get_width()
            if self.rect.top < 0:
                self.rect.top = 0
            if self.rect.bottom > self.screen.get_height():
                self.rect.bottom = self.screen.get_height()
            self.x = self.rect.centerx
            self.y = self.rect.centery

    def shoot(self):
        if self.health >=0:
            shot = []
            if self.shoot_timer <= 0:
                if self.shot_type == 'split':
                    shot.append(WaterBalloon(self.screen, self.x, self.y, self.angle + 15, False))
                    shot.append(WaterBalloon(self.screen, self.x, self.y, self.angle - 15, False))
                    shot.append(WaterBalloon(self.screen, self.x, self.y, self.angle - 15, False))
                    self.shoot_timer = self.shoot_timer_max
                    self.special_ammo -= 1
                elif self.shot_type == 'stream':
                    shot.append(Droplet(self.screen, self.x, self.y, self.angle))
                    self.shoot_timer = self.shoot_timer_max
                    self.special_ammo -= 1
                elif self.shot_type == 'burst':
                    shot.append(ExplosiveWaterBalloon(self.screen, self.x, self.y, self.angle))
                    self.shoot_timer = self.shoot_timer_max
                    self.special_ammo -= 1
                elif self.shot_type == 'flash':
                    shot.append(SpeedBalloon(self.screen, self.x, self.y, self.angle))
                    self.shoot_timer = self.shoot_timer_max
                    self.special_ammo -= 1
                else:
                    shot.append(WaterBalloon(self.screen, self.x, self.y, self.angle, False))
                    self.shoot_timer = self.shoot_timer_max
                if self. special_ammo <= 0:
                    self.powerUp('normal')
                    self.shoot_cooldown_max = 10
                self.sfx_shot.play()
                for projectile in shot:
                    projectile.damage += self.damage_boost
                    

    def powerUp(self, power_type):
        if power_type == 'crateammo':
            self.crate_ammo += 10
            self.getScore(10)
        if power_type == 'explosiveammo':
            self.explosive_crate_ammo += 10
            self.getScore(10)
        if power_type == 'split':
            self.shot_type = 'split'
            self.special_ammo = 40
            self.getScore(10)
            self.shoot_timer_max = 20
        if power_type == 'stream':
            self.shot_type = 'stream'
            self.special_ammo = 500
            self.getScore(10)
            self.shoot_timer_max = 2
        if power_type == 'burst':
            self.shot_type = 'burst'
            self.special_ammo  = 70
            self.shoot_timer_max = 100
            self.getScore(10)
        if power_type == 'magic':
            self.shot_type = 'magic'
            self.health += 10
            if self.health >= self.health_max:
                self.health = self.health_max
            self.getScore(10)
        if power_type == 'flash':
            self.speed += 10
            self.shot_type = 'flash'
            self.special_ammo = 50
            self.shoot_timer_max = 70
            self.speed_timer = self.speed_timer_max
            self.getScore(10)
        if power_type == 'companion':
            Companion(self.screen, self.x, self.y, self)
