import pygame
from toolbox import *
import random

class Particle(pygame.sprite.Sprite):
    def __init__(self, image, x, y,vx, vy, ax, ay, fx, fy, angle):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.image = image
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.rect = self.image.get_rect()
        self.ax = ax
        self.ay = ay
        self.fx = fx
        self.fy = fy
        self.angle = angle
        self.timer_max = 150
        self.timer = self.timer_max
        self.rotation_velocity = random.randint(-10, 20)
        self.rotation_friction = self.rotation_velocity / 50
        
    def update(self, screen):
        self.vx = max(0, self.vx - self.fx)
        self.vy = max(0, self.vy - self.fy)
        self.angle += self.rotation_velocity
        self.timer -= 1
        if self.rotation_velocity > 0:
            if self.rotation_velocity - self.rotation_friction > 0:
                self.rotation_velocity -= self.rotation_friction
            else:
                self.rotation_velocity = 0
        elif self.rotation_velocity < 0:
            if self.rotation_velocity - self.rotation_friction < 0:
                self.rotation_velocity -= self.rotation_friction
            else:
                self.rotation_velocity = 0
            
        #Move particle by vx and vy
        self.x += self.vx
        self.y += self.vy
        self.rect.center = (self.x,self.y)
        self.rotation_image, self.rotation_rect = getRotatedImage(self.image, self.rect, self.angle)
        if self.timer == 0:
            self.kill()
        #draw particle
        screen.blit(self.rotation_image, self.rotation_rect)
