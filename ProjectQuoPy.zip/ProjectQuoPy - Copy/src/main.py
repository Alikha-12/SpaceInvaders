import pygame
import random
from player import Player
from projectile import WaterBalloon
from enemy import * 
from crate import *
from explosion import *
from powerup import Powerup
from hud import *
from adv_enemy import *
from companion import *
from coin import *
from particle import *

# Start the game
pygame.init()
game_width = 1000
game_height = 650
screen = pygame.display.set_mode((game_width, game_height))
clock = pygame.time.Clock()
running = True
game_started = False
enemy_spawn_timer_max = 40
enemy_spawn_timer = enemy_spawn_timer_max
pygame.mixer.pre_init(buffer = 1024)
difficulty_timer_max = 500
difficulty_timer = difficulty_timer_max

background_image = None
def background():
    global background_image
    image = random.randint(0, 3)
    if image == 0:
        background_image = pygame.image.load("../assets/BG_SciFi.png")
    if image == 1:
        background_image = pygame.image.load("../assets/BG_Grass.png")
    if image == 2:
        background_image = pygame.image.load("../assets/BG_Sand.png")
    if image == 3:
        background_image = pygame.image.load("../assets/BG_Urban.png")
background()

explosion_images = []
explosion_images.append(pygame.image.load("../assets/LargeExplosion1.png"))
explosion_images.append(pygame.image.load("../assets/LargeExplosion2.png"))
explosion_images.append(pygame.image.load("../assets/LargeExplosion3.png"))


playerGroup = pygame.sprite.Group()
projectilesGroup = pygame.sprite.Group()
enemiesGroup = pygame.sprite.Group()
cratesGroup = pygame.sprite.Group()
explosionGroup = pygame.sprite.Group()
powerupGroup = pygame.sprite.Group()
companionGroup = pygame.sprite.Group()
coinGroup = pygame.sprite.Group()
particleGroup = pygame.sprite.Group()

Player.containers = playerGroup
WaterBalloon.containers = projectilesGroup
Enemy.containers = enemiesGroup
Crate.containers = cratesGroup
Explosion.containers = explosionGroup
Powerup.containers = powerupGroup
Companion.containers = companionGroup
Coin.containers = coinGroup
Particle.containers = particleGroup



player = Player(screen, game_width/2, game_height/2)
hud = HUD(screen, player)

def startGame():
    global game_started
    Coin(screen, 45, 45)
    game_started = True
    hud.state = 'ingame'
    player.__init__(screen, game_width/2, game_height/2)
    for i in range(10):
        Crate(screen, random.randint(0, game_width), random.randint(0, game_height), player)
        ExplosiveCrate(screen, random.randint(0, game_width), random.randint(0, game_height), player)
        Powerup(screen, random.randint(0, game_width), random.randint(0, game_height))
    if hud.difficulty == 'easy':
        Companion(screen, random.randint(0, game_width), random.randint(0, game_height), player)
        

def spawnEnemy():  
    edge = random.randint(0,3)
    if edge == 0:
        #top edge
        enemy_x = random.randint(0, game_width)
        enemy_y = -64
    elif edge == 1:
        #bottom edge
        enemy_x = random.randint(1, game_width)
        enemy_y = game_height + 64
    elif edge == 2:
        enemy_x = game_width + 64
        enemy_y = random.randint(0, game_height)
    elif edge == 3:
        enemy_x = -64
        enemy_y = random.randint(0, game_height)
    enemy = random.randint(0,3)
    if enemy == 0:
        Enemy(screen, enemy_x, enemy_y, player, hud.difficulty)
    if enemy == 1:
        ProjectileEnemy(screen, enemy_x, enemy_y, player, hud.difficulty)
    if enemy == 2:
        ExplosiveEnemy(screen, enemy_x, enemy_y, player, hud.difficulty)
    if enemy == 3:
        ExplosiveBarrel(screen, enemy_x, enemy_y, player, hud.difficulty)

def on_click(pos):
    if hud.state == 'mainmenu':
        button_x, button_y = toolbox.centeringCoord(hud.start_text, screen)
        button_rect = pygame.Rect(button_x, button_y + 50, hud.start_text.get_width(), hud.start_text.get_height())
        if button_rect.collidepoint(pos):
            startGame()
        button_x, button_y = toolbox.centeringCoord(hud.easy_button, screen)
        difficulty_button_rect = pygame.Rect(button_x, button_y + 180, hud.easy_button.get_width(), hud.easy_button.get_height())
        if difficulty_button_rect.collidepoint(pos):
            if hud.difficulty == 'easy':
                hud.difficulty = 'medium'
            elif hud.difficulty == 'medium':
                hud.difficulty = 'hard'
            elif hud.difficulty == 'hard':
                hud.difficulty = 'easy'
    if hud.state == 'upgrades':
        if hud.button1.rect.collidepoint(pos):
            if player.coin_counter >= 1 and player.health < player.health_max:
                player.health += 10
                player.coin_counter -= 1
                if player.health > player.health_max:
                    player.health = player.health_max
        if hud.button2.rect.collidepoint(pos):
            if player.coin_counter >= 1:
                player.coin_counter -= 1
                player.health_max += 50
        if hud.button3.rect.collidepoint(pos):
            if player.coin_counter >= 2:
                player.coin_counter -= 2
                player.coin_boost += 2
        if hud.button4.rect.collidepoint(pos):
            if player.coin_counter >= 1:
                player.coin_counter -= 1
                player.damage_boost += 7
                
            

# ***************** Loop Land Below *****************
# Everything under 'while running' will be repeated over and over again
while running:
    # Makes the game stop if the player clicks the X or presses esc
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif not game_started:
                startGame()
        if event.type == pygame.MOUSEBUTTONDOWN:
            on_click(event.pos)
            
   
    if game_started and hud.state == 'ingame':
        
        difficulty_timer -= 1
        if difficulty_timer <= 0:
            enemy_spawn_timer_max -= 5
            difficulty_timer = difficulty_timer_max
            if enemy_spawn_timer_max <= 0:
                enemy_spawn_timer_max = 5
        enemy_spawn_timer -= 1
        if enemy_spawn_timer <= 0:
            enemy_spawn_timer = enemy_spawn_timer_max
            spawnEnemy()
            
            
        if pygame.mouse.get_pressed()[0]:
            player.shoot()


        keys = pygame.key.get_pressed()
        if keys[pygame.K_d]:
            player.move(1, 0, cratesGroup)
        if keys[pygame.K_w]:
            player.move(0, -1, cratesGroup)
        if keys[pygame.K_a]:
            player.move(-1, 0, cratesGroup)
        if keys[pygame.K_s]:
            player.move(0, 1, cratesGroup)
        if keys[pygame.K_SPACE]:
            player.placeCrate()
        if pygame.mouse.get_pressed()[2]:
            player.placeExplosiveCrate()
        
                
        screen.blit(background_image, (0, 0))
        player.update(enemiesGroup, explosionGroup, projectilesGroup, coinGroup)
        if player.health <= 0:
            if hud.state == 'ingame':
                hud.state = 'gameover'
            elif hud.state == 'mainmenu':
                game_started = False
                playerGroup.empty()
                enemiesGroup.empty()
                projectilesGroup.empty()
                powerupGroup.empty()
                cratesGroup.empty()
                explosionGroup.empty()
        for projectile in projectilesGroup:
            projectile.update()

        for enemy in enemiesGroup:
            enemy.update(projectilesGroup, cratesGroup, explosionGroup)

        for crate in cratesGroup:
            crate.update(projectilesGroup, explosionGroup)

        for explosion in explosionGroup:
            explosion.update()

        for powerup in powerupGroup:
            powerup.update(player)

        for companion in companionGroup:
            companion.update(cratesGroup, enemiesGroup, explosionGroup, projectilesGroup)
            
        for coin in coinGroup:
            coin.update()

        for particle in particleGroup:
            particle.update(screen)

    else:
        screen.blit(background_image, (0, 0))
        
    hud.update()

    # Tell pygame to update the screen
    pygame.display.flip()
    clock.tick(40)
    pygame.display.set_caption("ATTACK OF THE ROBOTS fps: " + str(clock.get_fps()))
