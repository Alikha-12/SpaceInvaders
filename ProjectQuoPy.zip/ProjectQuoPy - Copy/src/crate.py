import pygame
from explosion import Explosion


class Crate(pygame.sprite.Sprite):
    def __init__(self, screen, x, y, player):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.screen = screen
        self.x = x
        self.y = y
        self.image = pygame.image.load("../assets/Crate.png")
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.image_hurt = pygame.image.load("../assets/Crate_hurt.png")
        self.hurt_timer = 0
        self.health = 10
        self.player = player
        self.just_placed = True
        self.sfx_break = pygame.mixer.Sound("../assets/sfx/break.wav")
        self.sfx_break.set_volume(0.5)
        

    def getHit(self, damage):
        self.health -= damage
        self.hurt_timer = 5
        if self.health <= 0:
            explosion_images = []
            explosion_images.append(pygame.image.load("../assets/LargeExplosion1.png"))
            explosion_images.append(pygame.image.load("../assets/LargeExplosion2.png"))
            explosion_images.append(pygame.image.load("../assets/LargeExplosion3.png"))
            Explosion(self.screen, self.x, self.y, explosion_images, 7, 1, False)
            self.health = 99999
            self.sfx_break.play()
            self.kill()

    def update(self, projectiles, explosions):
        if not self.rect.colliderect(self.player.rect):
            self.just_placed = False
            
        if self.hurt_timer > 0:
            self.hurt_timer -= 1
            image_to_draw = self.image_hurt
        else:
            image_to_draw = self.image
        self.screen.blit(image_to_draw, self.rect)
        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect):
                projectile.explode()
                self.getHit(projectile.damage)

        for explosion in explosions:
            if explosion.rect.colliderect(self.rect):
                if explosion.damage:
                    self.getHit(explosion.damage)



class ExplosiveCrate(Crate):
    def __init__(self, screen, x, y, player):
        Crate.__init__(self, screen, x, y, player)
        self.image = pygame.image.load("../assets/ExplosiveBarrel.png")
        self.image_hurt = pygame.image.load("../assets/ExplosiveBarrel_Hurt.png")
        self.sfx_break = pygame.mixer.Sound("../assets/sfx/explosion-big.wav")
        self.sfx_break.set_volume(0.5)

    def getHit(self, damage):
        self.health -= damage
        self.hurt_timer = 5
        if self.health <= 0:
            explosion_images = []
            explosion_images.append(pygame.image.load("../assets/LargeExplosion1.png"))
            explosion_images.append(pygame.image.load("../assets/LargeExplosion2.png"))
            explosion_images.append(pygame.image.load("../assets/LargeExplosion3.png"))
            Explosion(self.screen, self.x, self.y, explosion_images, 7, 1, False)
            Explosion(self.screen, self.x + 10, self.y - 20, explosion_images, 7, 1, False)
            Explosion(self.screen, self.x - 7, self.y + 15, explosion_images, 7, 1, False)
            Explosion(self.screen, self.x - 17, self.y + 27, explosion_images, 7, 1, False)
            Explosion(self.screen, self.x + 47, self.y - 15, explosion_images, 7, 1, False)


            self.sfx_break.play()
            self.health = 99999
            self.kill()
        
